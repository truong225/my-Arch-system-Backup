#! /bin/bash

cd ~/.config
var=$(<check_poweroff)

echo "0" > check_poweroff

systemctl reboot