#! /bin/bash

# Kiem tra trang thai battery co bi doi khong

while [[ 1 ]]
do
	#statements
	status=$(acpi -s|cut -d " " -f3|cut -d "," -f1)

	if [ "$status" != "Full" ] || [ "$status" != "Charging" ]
	then
	# 	xbacklight -set 100
	# else
	# 	xbacklight -set 40
		xbacklight -set 50
	fi

	unset status
done