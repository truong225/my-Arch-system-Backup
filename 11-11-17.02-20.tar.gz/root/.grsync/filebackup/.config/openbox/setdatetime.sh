#! /bin/bash

cd ~/.config
var=$(<check_poweroff)

if [ "$var" -eq "0" ]
then
	tim=$(date --date="7 hours ago" +%T)
	date --set=$tim
fi

echo "1" > check_poweroff