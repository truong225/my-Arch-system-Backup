# Aliases
alias pylint-quick='pylint --reports=n'
compdef _pylint-quick pylint-quick='pylint --reports=n'
