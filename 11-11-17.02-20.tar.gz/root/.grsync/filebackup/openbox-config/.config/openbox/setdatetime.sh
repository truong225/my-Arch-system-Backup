tim=$(date --date="7 hours ago" +%T)
date --set=$tim